﻿namespace StarWars.Api.Models
{
    public class Droid : Character
    {
        public string PrimaryFunction { get; set; }
    }
}
