﻿namespace StarWars.Data.EntityFramework.Workaround
{
    // WORKAROUND: https://docs.efproject.net/en/latest/miscellaneous/cli/dotnet.html#targeting-class-library-projects-is-not-supported
    public static class Program
    {
        public static void Main() { }
    }
}
