﻿using Nop.Core.Configuration;

namespace Nop.Core.IO
{
    public class FileSystemSettings : ISettings
    {
        public string DirectoryName { get; set; }
    }
}