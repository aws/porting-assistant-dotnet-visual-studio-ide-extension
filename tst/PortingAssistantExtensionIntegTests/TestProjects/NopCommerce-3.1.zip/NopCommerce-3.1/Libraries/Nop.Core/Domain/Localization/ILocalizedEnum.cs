
namespace Nop.Core.Domain.Localization
{
    /// <summary>
    /// Represents a localized enum
    /// </summary>
    public interface ILocalizedEnum
    {

    }
}
